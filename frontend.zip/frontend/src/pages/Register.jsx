// frontend/src/pages/Register.jsx
import { useState } from 'react'
import { api } from '../api'

export default function Register() {
  const [email, setEmail] = useState('')
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [msg, setMsg] = useState('')
  const [err, setErr] = useState('')

  async function handleSubmit(e) {
    e.preventDefault()
    setErr('')
    setMsg('')
    try {
      await api.register(email, username, password)
      setMsg('registered, check email (if enabled)')
    } catch (e) {
      setErr(e?.error?.message || 'failed')
    }
  }

  return (
    <div>
      <h2>Register</h2>
      {msg && <p style={{ color: 'green' }}>{msg}</p>}
      {err && <p style={{ color: 'red' }}>{err}</p>}
      <form onSubmit={handleSubmit}>
        <input placeholder="email" value={email} onChange={e => setEmail(e.target.value)} />
        <input placeholder="username" value={username} onChange={e => setUsername(e.target.value)} />
        <input placeholder="password" type="password" value={password} onChange={e => setPassword(e.target.value)} />
        <button>Sign up</button>
      </form>
    </div>
  )
}
