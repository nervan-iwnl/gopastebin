// frontend/src/api.js
const API_BASE = import.meta.env.VITE_API_BASE;

async function request(path, { method = 'GET', body, headers } = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(headers || {}),
    },
    body: body ? JSON.stringify(body) : undefined,
    credentials: 'include', // ← важная строка
  });

  const text = await res.text();
  let data;
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = { raw: text };
  }

  if (!res.ok) {
    throw data;
  }
  return data;
}

export const api = {
  me: () => request('/auth/me'),
  login: (login, password) => request('/auth/login', { method: 'POST', body: { login, password } }),
  register: (email, username, password) => request('/auth/register', { method: 'POST', body: { email, username, password } }),

  myPastes: () => request('/me/pastes'),
  createPaste: (payload) => request('/pastes', { method: 'POST', body: payload }),
  getPaste: (slug) => request(`/pastes/${slug}`),
  getRecent: () => request('/pastes/recent'),

  getStorage: () => request('/settings/storage'),
  setStorage: (storage) => request('/settings/storage', { method: 'POST', body: { storage } }),
};
