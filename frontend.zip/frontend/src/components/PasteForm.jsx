// frontend/src/components/PasteForm.jsx
import { useState } from 'react'
import { api } from '../api'

export default function PasteForm({ onCreated }) {
  const [title, setTitle] = useState('')
  const [content, setContent] = useState('')
  const [folder, setFolder] = useState('')
  const [slug, setSlug] = useState('')
  const [error, setError] = useState('')

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    try {
      await api.createPaste({
        title,
        content,
        extension: 'txt',
        folder,
        slug,
        is_public: true,
      })
      setTitle('')
      setContent('')
      setFolder('')
      setSlug('')
      onCreated && onCreated()
    } catch (e) {
      setError(e?.error?.message || 'failed')
    }
  }

  return (
    <form onSubmit={handleSubmit} style={{ marginBottom: 20 }}>
      <h3>Create paste</h3>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <input placeholder="title" value={title} onChange={e => setTitle(e.target.value)} />
      <input placeholder="folder (like project-euler/001-100)" value={folder} onChange={e => setFolder(e.target.value)} />
      <input placeholder="custom slug (optional)" value={slug} onChange={e => setSlug(e.target.value)} />
      <textarea placeholder="content" value={content} onChange={e => setContent(e.target.value)} />
      <button>Create</button>
    </form>
  )
}
