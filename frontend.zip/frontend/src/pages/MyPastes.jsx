// frontend/src/pages/MyPastes.jsx
import { useEffect, useState } from 'react'
import { api } from '../api'
import PasteForm from '../components/PasteForm.jsx'

export default function MyPastes() {
  const [pastes, setPastes] = useState([])
  const [error, setError] = useState('')

  async function load() {
    try {
      const data = await api.myPastes()
      setPastes(data.pastes || data || [])
    } catch (e) {
      setError('need login?')
    }
  }

  useEffect(() => {
    load()
  }, [])

  return (
    <div>
      <h2>My pastes</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <PasteForm onCreated={load} />
      <ul>
        {pastes.map(p => (
          <li key={p.slug}>
            <strong>{p.title}</strong> ({p.slug}) — {p.folder}
          </li>
        ))}
      </ul>
    </div>
  )
}
