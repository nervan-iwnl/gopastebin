// frontend/src/components/Nav.jsx
import { Link } from 'react-router-dom'

export default function Nav() {
  return (
    <nav style={{ background: '#222', padding: '10px 20px', color: '#fff' }}>
      <Link to="/" style={{ color: '#fff', marginRight: 15 }}>My pastes</Link>
      <Link to="/p/test" style={{ color: '#fff', marginRight: 15 }}>Open paste</Link>
      <Link to="/admin/storage" style={{ color: '#fff', marginRight: 15 }}>Admin</Link>
      <Link to="/login" style={{ color: '#fff', marginRight: 15, float: 'right' }}>Login</Link>
    </nav>
  )
}
