// frontend/src/pages/PasteView.jsx
import { useParams } from 'react-router-dom'
import { useEffect, useState } from 'react'
import { api } from '../api'

export default function PasteView() {
  const { slug } = useParams()
  const [paste, setPaste] = useState(null)
  const [raw, setRaw] = useState('')
  const [err, setErr] = useState('')

  useEffect(() => {
    async function load() {
      try {
        const data = await api.getPaste(slug)
        setPaste(data.paste || data)
        // подгрузим raw
        const res = await fetch(`${import.meta.env.VITE_API_BASE}/pastes/${slug}/raw`)
        const txt = await res.text()
        setRaw(txt)
      } catch (e) {
        setErr('not found')
      }
    }
    load()
  }, [slug])

  if (err) return <p>{err}</p>

  return (
    <div>
      <h2>{paste?.title} ({slug})</h2>
      <pre style={{ background: '#eee', padding: 10 }}>{raw}</pre>
    </div>
  )
}
