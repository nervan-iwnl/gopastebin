// frontend/src/pages/Login.jsx
import { useState } from 'react'
import { api } from '../api'
import { useNavigate } from 'react-router-dom'

export default function Login() {
  const [login, setLogin] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const navigate = useNavigate()

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    try {
      await api.login(login, password)
      navigate('/')
    } catch (err) {
      setError(err?.error?.message || 'login failed')
    }
  }

  return (
    <div>
      <h2>Login</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <form onSubmit={handleSubmit}>
        <div>
          <input placeholder="email or username"
            value={login}
            onChange={e => setLogin(e.target.value)}
          />
        </div>
        <div>
          <input placeholder="password" type="password"
            value={password}
            onChange={e => setPassword(e.target.value)}
          />
        </div>
        <button>Sign in</button>
      </form>
    </div>
  )
}
